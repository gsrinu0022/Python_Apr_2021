# tuple is a python collection
# tuple starts with ( ends with )
# tuple index starts with 0
# tuple length starts with 1

tpl=(1001,"sreenivas","qual")
print(tpl)
print(tpl[0])

print(tpl[0:2]) # [first index included : second index -1 ]

#print(tpl[3])

#tpl.append("sreenivas")

# mutable :
#     we can able to add,remove and replace values from object
#     list is mutable 

# immutable :
#     we can't able to add,remove and replace values from object
#     tuple is immutable 

print(len(tpl))
#print(count(tpl))
# print(max(tpl))
# print(min(tpl))

tpl1=(23,23,12,56,57,12,9)
print(max(tpl1))
print(min(tpl1))
print(len(tpl1))







