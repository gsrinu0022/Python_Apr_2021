# range represents a sequence of numbers ,the numbers in range cannot be modified 
# range mostly using in loops 

# range : number of students in the class 
# range of our python class 123 

r=range(10) # range index starts with 0 
# range (10) # 0,1,2,3,4,5,6,7,8,9

 

print(r[1])
print(r[0])
#print(r[10]) # range object index out of range

for i in r :print(i)

# range with step 

r1=range(1,20,2)
print(r1)

for i in r1 :print(i)
# do't take step value with negative 



r3=range(60,40,-2)
for i in r3:print(i)

print(range(20)) # 20 index values will get
print(range(10,20)) # 
print(range(10,40,5))

for i in range(20):print(i)
for i in range(10,20):print(i)
for i in range(10,40,5):print(i)


