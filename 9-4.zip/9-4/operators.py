python provides mutiple operators below 
=======================================
 1.arthematic 
 2.assignement 
 3.comparison
 4.logical 
 5.identity 
 6.membership 
 7.bitwise 
 
  1.arthematic
  ============
    +  addition
    -  subtraction
    * multiplication
    / divison
    % modulus 
    ** exponent 
    // floor divison 
    
  1.Assignment 
  ============
    =
    +=
    -=
    *=
    /=
    %= 
    //=
    **=
    |=
    
3.comparison
=============
 ==
 !=
 >
 <
 >=
 <=
 
 logical operators 
 =================
  and  
  or   
  not  
  
   5.identity 
   ==========
    is 
    is not 
  
  6. membership 
  ============
  
   in
   not in 
    
    7.bitwise 
    =========
    
    &
    |
    ^
    <<
    >>
    
    
    
    
    