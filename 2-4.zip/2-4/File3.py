print("hello python")

x=2
y=3
z=x+y
print("z value is",z)
name="sreenivas"

if name=="sreeni":
    print("ok matched")
else:
    print("not matched")
        

