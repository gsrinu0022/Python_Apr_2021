print("hello python")
name="sreenivas"
print("name is",name)

