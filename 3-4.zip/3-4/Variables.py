
# x=10
# y=20
# z=x+y
# print("z value is ",z)

#x=10; y=20; z=x+y; print(z);

x,y,z,a = 10,20,30,40

print(x)
print(y)
print(z)
print(a)

name="sreenivas"
age= 34
qual= 'mca'

print(name)
print(age)
print(qual)

name,age,qual="suresh",31,"btech"

print(name)
print(age)
print(qual)

# ; is end of the statement 
# , separate in statement 

print(234+345)
print("hyd " + " python")


