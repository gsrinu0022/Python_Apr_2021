# print funtion 
print("hello python")
print("hello python developers")

# addition program 

"""
x=12
y=15
add=x+y
print("addition is",add)
"""
 
print("hello all above commented ")
