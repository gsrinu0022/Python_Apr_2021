#conditions
# if 
# if else 
# elif 

# if ==> if is a condition checks only true statements 

# var name="sreenivas"
# if (name=="sreenivas")
# {
#     console.log("ok")
# }

# in python for conditions no () need 
#no { } need for block of the code 
# indentation and : will be added in python 
# when we give colon: automatically python interpreter 
# makes u indentation in the next line for block of the condition

name="sreenivas"
# () not required 
# : for entry point of condition block 
#  indentation is 4 spaces or tab automatically take 

if name=="sreenivas":
    print("ok name identified")
    

# if else 
# if else is going to be checking true and false blocks

if name=="sreeniva":
    # true block
    print("name matched")
else :
    # false block
    print("name not matched")
    
#elif 
# elif is going to be checking mutiple statements in to check the condition

name="swapna"
if name=="swap":
    print("not matched")
elif name=="swapn":
    print("check once more")
elif name=="swa":
    print("check need more..")
elif name=="swapna":
    print("ys i got it")
else:
    print("name is not matching ...")
    
# another program 

loc = 'Bank'
if loc == 'Auto Shop':
    print('Welcome to the Auto Shop!')
elif loc == 'Bank':
    print('Welcome to the bank!')
elif loc == 'School':
    print('Welcome to the School')
else:
    print('Where are you?')
    
# another program 
marks =45

if marks<35:
    print("he got fail")
elif marks>35 and marks<60:
    print("B grade")
elif marks>60 and marks<80:
    print("A grade")
elif marks>80:
    print("distinction")
    
# nested if 
# she is graduted or not 
name="female"
graduated=True

if name=="male":
    print("male")
else:
    print("female")
    if graduated==True:
        print("she got graduated")
    else:
        print("she was not graduated")



    
    
    
    