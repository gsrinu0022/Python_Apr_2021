#loops : checking itterations 
# 1.while 
# 2.for 

# loops 
# syn
# init 
# checking condition
# printing statements 
# inc or dec 
  
fruits=["apple","bannana","orange"]
i=0 # init 
while i<len(fruits):
    print(fruits[i])
    i=i+1

#ex-2
x = 0
while x < 10:
    print('x is currently: ',x)
    print(' x is still less than 10, adding 1 to x')
    x+=1
    
# the above block of the code will be executing to u until condition is not sartisfy
# once condition not sartisfy loop will terminate automatically 

x = 0
while x < 10:
    if x%2==0:
        print("{0} is even number".format(x))
    else:
        print("{0} is odd number".format(x))
    x+=1
    
# for loop 
fruits=["apple","bannana","orange"]
for i in range(len(fruits)):
    print(fruits[i])
    
# ex-2 
 
for i in range(10):
    print(i)
    
# ex-3
for i in range(10):
    if i%2==0:
        print("{0} is even ".format(i))
    else:
         print("{0} is odd ".format(i))
