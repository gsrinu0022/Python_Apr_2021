# list is acollection object in python
# list starts with [ ends with ]
# index stars with 0
# length starts with 1 
# every object inside list separated with comma 
# last object we do not give comma 

lst=[10,20,'sreenivas',-99.5]
print(lst)
print(type(lst))
print( 'first index is...',lst[0] )

lst1=[]# empty list
print(lst1)

print( 'after first index is...',lst[1:] )

print(lst[1:2]) # [firstindex : secondindex-1] ==> first index 

lst1=["apple","bannnana","orange","grapes"]
print(lst1[:])
print(lst1[2:]) # second index will be included 

print(lst1[1:-3])
print(lst1[1:-1])
print(len(lst1)) # len() is a python function to get no of values in side list

lst1=[]# empty list
print(lst1)
lst1.append(["sreenivas","swetha"]) # appending array object in side array
print(lst1)
lst1.append("swapna")
lst1.append(345)
print(lst1)

lst1.append( (10,20,30) ) # appending tuple inside array

print(lst1)




