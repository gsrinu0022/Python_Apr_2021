# dictionary
# ==========
#   dic is a collection of key-value paires 
#   dic starts with { closed }
#   key and value separated with :
#   every key-value pair separated with comma 
#   last key-value pair do not have comma 

dic_obj={
    
     'name':'sreeenivas',
     'qual':"mca",
     'location':'hyd'
}

print(dic_obj)
print(type(dic_obj))

print(dic_obj['name'])
print(dic_obj['qual'])
print(dic_obj['location'])

dic_obj1={
    
     'name':'sreeenivas',
     'technologies':['WEB',"PYTHON","DS"]  
}
print(dic_obj1)

print(dic_obj1['technologies'])

print(dic_obj1['technologies'][1])


