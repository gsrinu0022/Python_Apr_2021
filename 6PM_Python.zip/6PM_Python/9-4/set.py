# set 
# ====
#  set is similar to list and tuple 
#  diff between the list and set 

#  list duplicates will be allowed 
#  in sets dupliates will not be allowed 
#  set will create from { closed with }
#  set is a collection datatype 

set_obj={"apple","bannana","orange","orange","orange"}
print(set_obj) 
print(type(set_obj))

# print(set_obj[0])

for x in set_obj:print(x)

set_obj.add("mango")
print(set_obj) 
#set_obj.add(["tamoto","chilli"])
set_obj.add(("tamoto","chilli"))
#set_obj.add(['123','123'])

print(set_obj) 




# list_obj =["apple","bannana","orange","orange","orange"]
# print(list_obj)

# tuple_obj= ("apple","bannana","orange","orange","orange")
# print(tuple_obj)
