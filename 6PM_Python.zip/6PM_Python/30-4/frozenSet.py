# set : unique order collection 

set= {1,3,4,6,78,9,0,5,6,1,3,6}
print(set)

# {0, 1, 3, 4, 5, 6, 9, 78}

set.add(199)

print(set)
# {0, 1, 3, 4, 5, 6, 199, 9, 78}

# tuple of vowels
vowels = ('a', 'e', 'i', 'o', 'u')
print(vowels)
fSet = frozenset(vowels)
print('The frozen set is:', fSet)

# frozenset({'e', 'u', 'o', 'a', 'i'})
#  ({}) = {} + ()
# frozenset= set+tuple 

print('The empty frozen set is:', frozenset())
#fSet.add('v')

# Traceback (most recent call last):
#   File "/Users/apple/Desktop/6PM_Python/30-4/frozenSet.py", line 24, in <module>
#     fSet.add('v')
# AttributeError: 'frozenset' object has no attribute 'add'

# random dictionary
person = {"name": "John", "age": 23, "gender": "male"}

fSet = frozenset(person)
print('The frozen set is:', fSet)

# The frozen set is: frozenset({'age', 'gender', 'name'})

# Frozensets
# initialize A and B
A = frozenset([1, 2, 3, 4])
B = frozenset([3, 4, 5, 6])

# copying a frozenset
C = A.copy()  # Output: frozenset({1, 2, 3, 4})
print("C is...",C)

# 1,2,3,4,  3,4,5,6 ==> 1,2,3,4,5,6

# union
print(A.union(B))  # Output: frozenset({1, 2, 3, 4, 5, 6})
# 1,2,3,4    3,4,5,6 ==> 3,4 

# intersection
print(A.intersection(B))  # Output: frozenset({3, 4})



# difference
print(A.difference(B))  # Output: frozenset({1, 2})
 #1,2,3,4,  3,4,5,6  => 1,2 


# symmetric_difference
print(A.symmetric_difference(B))  # Output: frozenset({1, 2, 5, 6})



