# funtion is a set of statements in python 

# not with funtion keyword  
# we do not have  { }  function block  

# in python funtions can be defined with def keyword 
# in python : and indentation will be used for function block 
# indentation is 4 spaces or 1 tab 
# indentation available for funtions loops and condtions 

# funtion without parameters 
def sayHello():
    print("hello python developrs")
sayHello()

# funtion with  two parameters 
def addTwoNumbers(a,b):
    print("addition is...", a+b)
addTwoNumbers(10,14)

# funtion with three parameters
def stuDetails (a,b,c):
    print("name is.. {0} qual is.. {1} and address is...{2}".format(a,b,c))
    
stuDetails("sreenivas","MCA","Hyderabad")

def square(a):
    print(a**2)
square(1223434678)
    