

# def square(a):
#     print(a**2)
# square(4)

# numbers = (1, 2, 3, 4)
# print(numbers)
# # (1,2,3,4)

# result = map(square, numbers)
# print(result)
# # <map object at 0x7ff3eee34fa0>

# square = set(result)
# print(square)
# 1
# 4 
# 9
# 16

numbers = (1, 2, 3, 4)
result = map(lambda x: x*x, numbers)
print(result)

# converting map object to set
numbersSquare = set(result)
print(numbersSquare)

# <map object at 0x7feceeaeafa0>
# {16, 1, 4, 9}

num1 = [4, 5, 6]
num2 = [5, 6, 7]

result = map(lambda n1, n2: n1+n2, num1, num2)
print(list(result))

# [9, 11, 13]




