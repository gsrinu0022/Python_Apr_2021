# lambda funtion is short hand funtion
# lamda funtion is anynomous funtion 

# normal funtion 
def square(a):
    print(a**2)
square(1223434678)

#lamda funtion 
f1 =lambda a: a**2
print(f1(4))

    
# lambda funtion for addition 

add=lambda a,b:a+b

print(add(2,4))

add=lambda a,b,c:a+b-c
print(add(12,4,5))