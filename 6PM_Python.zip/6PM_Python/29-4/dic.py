dic = {"name":"sreenivas","qual":"mca","age":32}
print(dic)

print(dic['name'])
print(dic['qual'])
print(dic['age'])
# there is no index process in the dictionary.
# if u want to access any value key we should mention.

my_dict = {'key1':123,'key2':[12,23,33],'key3':['item0','item1','item2']}
print(my_dict)

print(my_dict['key3'])

print(my_dict['key3'][0])

# convert value into uppercase
print(my_dict['key3'][0].upper())

print(my_dict['key1'])

print(my_dict['key1']-123)

my_dic =my_dict['key1']-123
print(my_dic)

print(my_dict['key1']-123)

# empty dic 

d={}
print(d)
d['animal']='dog'
d['bird']='parrot'
print(d)

d = {'key1':{'nestkey':{'subnestkey':'value'}}}

print(d['key1'])

print(d['key1']['nestkey'])

print(d['key1']['nestkey']['subnestkey'])

d = {'key1':1,'key2':2,'key3':3}

# gather all keys 
print(d.keys())
# dict_keys(['key1', 'key2', 'key3'])

# gather all values 
print(d.values())
# dict_values([1, 2, 3])

print(d.items())
# dict_items([('key1', 1), ('key2', 2), ('key3', 3)])


