# Tuples
# In Python tuples are very similar to lists, however, unlike lists they are immutable meaning 
# they can not be changed. You would use tuples to present things that shouldn't be changed, 
# such as days of the week, or dates on a calendar.

#mutable  : changable  (list)   [ ]  , collection of values  , index will work 
#immutable : not changable (tuple)  ( ) , collection of values  ,index will work 

tup =('sreenivas','mca',32)
print(tup)

# ('sreenivas', 'mca', 32)

#gather index 0 item
print(tup[0])
# sreenivas

print(tup[1:])
# ('mca', 32)

print(tup[-1])

print (tup.index('mca'))
# 1

#tup[0]='swapna'

# File "/Users/apple/Desktop/6PM_Python/29-4/tuples.py", line 26, in <module>
#     tup[0]='swapna'
# TypeError: 'tuple' object does not support item assignment

#tup.append('sreekanth')

#  File "/Users/apple/Desktop/6PM_Python/29-4/tuples.py", line 32, in <module>
#     tup.append('sreekanth')
# AttributeError: 'tuple' object has no attribute 'append'