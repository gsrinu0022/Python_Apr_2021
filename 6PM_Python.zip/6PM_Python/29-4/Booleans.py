a=True
print(a)
#True 

print(1>2)
# False

b=None
print(b)
# None

print(1>4 and 3<5)

print(2<5 and 5<12)

print(3 is 4 or 5 is 5)
