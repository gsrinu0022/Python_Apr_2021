# lambda funtions are shory way of writing funtions 
# lamda funtions are anyynomous funtion 

#square funtion
def square(a):
    return print(a*a)

square(5)
square(25)

# lambda squre funtion 

f= lambda a : a*a
print(f(3))

# 9

f1=lambda a: print(a*a*a)
f1(5)
# 125