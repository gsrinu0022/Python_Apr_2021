# funtions 
#============
 # functions are set of statements which will execute at particualr  situaltions 
 
 # define funtion in python using with def keyword 
 
         # in other programming 
 
#  function funtionName()
#  {
#       function body
#  }

       # in python 
    
# defining funtion 
def functionName():
    print("hello all python developers")
    
# calling funtion 
functionName()

# hello all python developers

#note : in python funtion body starts with : and indentation 
#indentation will be 4 spaces or 1 tab 
# in python programming we need to absorve spaces very careful 

def addNumbers(a,b):
    return print("addition is", a+b)

addNumbers(10,20)
addNumbers(110,240)

#square funtion
def square(a):
    return print(a*a)

square(5)
square(25)

# cube funtion 
def cube(a):
    return print(a*a*a)

cube(5)
cube(25)





