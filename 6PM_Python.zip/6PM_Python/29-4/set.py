#set is a collection same like a list 
#set will not allow duplicates

list =['1','2','3','4','1','2']
print(list) 
# ['1', '2', '3', '4', '1', '2']

setObj={'1','2','3','4','1','2'}
print(setObj)
# {'1', '2', '4', '3'}

s= set()
s.add(1)
print(s)

# {1}

# Create a list with repeats
list1 = [1,1,2,2,3,4,5,6,1,1]
print(list1)

# Cast as set to get unique values
print(set(list1))

# {1, 2, 3, 4, 5, 6}

