name="sreenivas"
print(name)
loc="hyderabad"

# int ==> %i or %d
# float ==> %f 
# string ==> %s 

print("name is {0}.. ".format(name))
print("name is {0}..loaction is {1} ".format(name,loc))

name="swapna"
fruitname="apple"
time=2

# swapna eat a apple in 2 minus  
print("{0} eat {1} in {2} mins ..".format(name,fruitname,time))   