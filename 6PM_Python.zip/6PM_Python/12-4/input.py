x=input("enter first number")
y=input("enter second number")
z=x+y

print("z value is",z) # z value is concatnation

# by default input will takes string 

x=int(input("enter first number"))
y=int(input("enter second number"))
z=x+y
print("z value is",z)  # z value is addition
