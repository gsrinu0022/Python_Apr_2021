# list is a collection same like array in other programing lans
# list1=["apple","android","samsung","lg"]
# print(list1)
# # list started with index 0
# # list lenghth starts with 1 
# print(list1[0])
# print(list1[2:])
# print(list1[:])
# print(list1[:2])
# print(list1[1:-2])


# my_list = ['A string',23,100.232,'o']
# # finding length of the list
# print(len(my_list))

# add new item for list 
# my_list=my_list + ['new item']
# print(my_list)
# # make double 
# print(my_list*2)

# Create a new list
# list1 = [1,2,3]
# # Append
# list1.append('append me!')
# # Show
# print(list1)

# # Pop off the 0 indexed item
# list1.pop(0)
# # Show
# print(list1)

# # Assign the popped element, remember default popped index is -1
# popped_item = list1.pop()
# print(popped_item)
# print(list1)

# # Show remaining list
# #list1[100]

# #  File "/Users/apple/Desktop/6PM_Python/27-4/list.py", line 41, in <module>
# #     list1[100]
# # IndexError: list index out of range


# new_list = ['a','e','x','b','c']

# #Show
# print(new_list)
# # Use reverse to reverse order (this is permanent!)
# new_list=new_list.reverse()
# print(new_list)

# # Use sort to sort the list (in this case alphabetical order, but for numbers it will go ascending)
# new_list= new_list.sort()
# print(new_list)

# list2=[23,56,34,56,12]
# list3=list2.sort()
# print(list3)

# Let's make three lists
lst_1=[1,2,3]
lst_2=[4,5,6]
lst_3=[7,8,9]

# Make a list of lists to form a matrix
matrix = [lst_1,lst_2,lst_3]

print(matrix)
# Grab first item in matrix object
print(matrix[0])

# Grab first item of the first item in the matrix object
print(matrix[0][0])

#List Comprehensions
first_col = [row[0] for row in matrix]
print(first_col)

second_col = [row[1] for row in matrix]
print(second_col)

third_col = [row[2] for row in matrix]
print(third_col)

print(matrix[0])