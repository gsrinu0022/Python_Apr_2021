print("hello python")
x=2
print("x value is ",x)
y=4
print("y value is",y)
z = x+y 
print("z value is ",z)
print(z)
type(z)
id(z)
