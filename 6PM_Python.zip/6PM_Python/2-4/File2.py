print("hello python")

name="sreenivas"
print(name)

if name=="sreenivas":
	print("value matched")

# if (name=="sreenivas")
# {
# 	console.log("value matched")
# }