
# place holder process 
empId=1001
empName="sreekanth"
empQual="Btech"
print("emp Id is... {0}".format(empId))
print("emp name is... {0}".format(empName))
print("emp Qual is... {0}".format(empQual))
print("{0} is having emp id {1}".format(empName,empId))
print("{0} is having emp id {1} and Qualified with {2}".format(empName,empId,empQual))
print("{a} is having emp id {b} and Qualified with {c}".format(a=empName,b=empId,c=empQual))

# another way  (specifier)

name="sreenivas"
salary=120000
print('%s ..earned... %s amount per month' %(name,salary))

x, y = 'Sreenivas', 100000
print(" %s is earning %s salary per month " %(x,y))

print('Floating point numbers: %5.2f' %(13.144)) # 13.14
print('Floating point numbers: %7.2f' %(13.144)) # 13.14
print('Floating point numbers: %17.2f' %(13.144)) # 13.14
# %length . spcifynumbers format 


print('First: %s, Second: %5.2f, Third: %s' %('hi!',3.1415,'bye!'))
#First: hi!, Second:  3.14, Third: bye!

print('First: %s, Second: %5.3f, Third: %s' %('hi!',3.1415,'bye!'))
#First: hi!, Second: 3.142, Third: bye!

print('{0:8} | {1:9}'.format('Fruit', 'Quantity'))
print('{0:8} | {1:9}'.format('Apples', 3.))
print('{0:8} | {1:9}'.format('Oranges', 10))

Fruit    | Quantity 
Apples   |       3.0
Oranges  |        10



