# String :
#     Collection of chars 
#     how to place string in python 
#     using with " "  or '' 

name="python"
print("basic course...." , name)

courseName='Django'
print("adv course ....", courseName)

locName=''' Hyderabad '''
print('location is...' ,locName)

# basic course.... python
# adv course .... Django
# location is...  Hyderabad 

#str="i like "python" "
# entry point with " exit point double codes  then in side double codes it will confuse "

str="i like 'python' "
print(str)

str1="i like \"python\" "
print(str1)

str2=""" i like "python"  """
print(str2)

print( 'sreeenivas \'s phone is iPhone' )


print('Hello World 1')
print('Hello World 2')
print('Use \n to print a new line')
print('\n')
print('See what I mean?')

# Hello World 1
# Hello World 2
# Use 
#  to print a new line

# See what I mean?

print(len(str2))

print("sreenibvas\tis\tteachng\tpython")
# i tab is 4 spaces 

fruit="Apple"
print(fruit[0])
print(fruit[1])
print(fruit[2])
# index starts from 0 
# length starts from 1 

print(fruit[:])
print(fruit[1:])
# [1:] 1 index included and after all values printing ..

print(fruit[1:2])
# [1:2] 1index included  2index-1 

str2="hello all good evening"
print(str2[1:15:2])





