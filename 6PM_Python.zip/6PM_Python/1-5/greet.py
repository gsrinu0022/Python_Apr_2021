
def greeting(name):
  print("Hello, " + name)

def sayHello():
	print("hello python developers")

def addition(a,b):
	print(a+b)

person1 = {
  "name": "Sreenivas",
  "age": 32,
  "country": "india"
}

fruits=['apple',"bannana"]