# import greet

import greet as aaa
aaa.greeting("Sreenivas")
aaa.sayHello()
aaa.addition(24,45)
aaa.addition(123,145)

a=aaa.person1["name"]
print("name is",a)

b=aaa.person1["age"]
print("age is", b)

myfavfruit= aaa.fruits[0]
print("i like ", myfavfruit)