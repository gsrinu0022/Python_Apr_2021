
name="sreenivas"
print(type(name)) 
print(id(name))
#<class 'str'>

emp_id=1001
print(type(emp_id))
print(id(emp_id))
#<class 'int'>

emp_weight=67.67
print(type(emp_weight))
print(id(emp_weight))
# <class 'float'>

# <class 'str'>
# 140214831239088
# <class 'int'>
# 140214831838320
# <class 'float'>
# 140214831838512