# variables 
# =========

# x=10
# y=20
# z=x+y
# print("z value is",z)
# name="sreenivas"
# print("name is ",name)

# emp name="sreenivas"
# print(emp name)

_emp_name="sreenivas"
print(_emp_name)

# 123empname="sreenivas"
# print(123empname)

# if="sreenivas"
# print(if)

# emp$123="sreenivas"
# print(emp$123)

# emp_$_name="sreenivas"
# print(emp_$_name)



# Keywords in Python programming language
#==========================================
# False	await	else	import	pass
# None	break	except	in	raise
# True	class	finally	is	return
# and	continue	for	lambda	try
# as	def	from	nonlocal	while
# assert	del	global	not	with
# async	elif	if	or	yield

_empname="sreenivas"
print(_empname)


x,y,z = 10,20,30
  
print(x)
print(y)
print(z)
  
print(x+y)
print(x+y+z)
  
x=10;y=20;z=30
# semicolon is optional at end of the statement 
print(x)
print(y)
print(z)




 
 
 