#String Type
name="sreenivas"
print(name)
# sreenivas
print(" type of the name....", type(name) )
# type of the name.... <class 'str'>
print(" memory location of name....",id(name) )
#memory location of name.... 140418270711728

location='hyderabad'
print(location)
print('type of the location....', type(location) )
print('memory location of location....',id(location) )
# type of the location.... <class 'str'>
# memory location of location.... 140396486541424

''' 
print(location)
print(location)
'''

"""
print(location)
print(location)
"""

coursename='''Python'''
print('''course name is  ....''',coursename )

# numbers  
# Int 
noOfStudents= 120
print('noOfStudents ...', noOfStudents)
print('noOfStudents  type is ...', type(noOfStudents))

# noOfStudents ... 120
# noOfStudents  type is ... <class 'int'>

x=10
y=20


addition=x+y # 10+20
print("addition is ",addition)

subtraction=x-y # 10-20
print("subtraction is ",subtraction)

multiplication=x*y # 10*20
print("mul iss....",multiplication)

exponent = x**y # 10**20
print("exp is....",exponent)

div =x/y # 10/20
print("div is....",div)

moddiv=x%y # 10%20 
print("mod div is...",moddiv)

# addition is  30
# subtraction is  -10
# mul iss.... 200
# exp is.... 100000000000000000000
# div is.... 0.5
# mod div is... 10

a=12
b="sreenivas"
#print(a+b) # error  (Int+Str)  int and str cannot add 
print(str(a) + b) #  (str+ str) ===> 12sreenivas 
#print(a + int(b)) # error string cannot convert to int

# Float 

weight=78.78
print(weight)
print("weight is....", type(weight))

# 78.78
# weight is.... <class 'float'>

# complex 

c=2j
print(c)
print("complex data is,..",type(c))
#print("int data is,..",int(c))


#2j
#complex data is,.. <class 'complex'>


# list datatype 

names=["sreenivas","suresh","swathi"]
# list index starts with 0
# list length starts with 1 

print(names)
print(names[0])
print(names[1])
print(names[2])

print("length of the list...", len(names))
# length of the list... 3







































 