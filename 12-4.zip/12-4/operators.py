# arthematic operators 

x=10
y=5 
print(x+y) # addition
print(x-y) #subtraction
print(x*y) #multiplication
print(x/y) # divison
print(x%y) # mod div
print(x//y)#floor divison
print(x**y)# exponentation

#Assignment Operators

x=3
print(x)

x+=3
print(x)

x-=3
print(x)

x/=3
print(x)

x//3
print(x)

x**=3
print(x)

print(x)


#comparison operators 

print(x==y) # equal
print(x!=y) # not equal
print(x<y) # lessthan
print(x>y) # greater than
print(x<=y) # lessthan or equal to
print(x>=y) ## greaterthan or equal to

#logical operators 
# and 
# or
# not 

x=10
y=20

print(x<5 and x<10) # false and false ==> false

print(x<5 or x<10) # false or false ===> false 

print(x>5 or y>10) # true or true   ==> true 

print (not(x>5 or y>10)) # true ==> false 

#Identity Operator 
# is 
# is not 
name="sreenivas"
a = name is 'sreenu'

print('identity ', a)
print(name is 'sreenivas')
print(name is not 'sreenivas')

#membership operator 
fruits =['apple','bannana','orange','grape']

print('apple' in fruits) # true 

print('Apple' not in fruits) # true


#bitwise opertaors

print(10&2)   #AND  1010 & 0010 ==> 0010
print(10|2)   #OR   1010 | 0010 
print(5^2)    #XOR
print(10<<2)  #leftshift 
print(10>>2)  #rightshift








